<?php 

// Desarrollado por Joystick para todos
// Julio 2019 - Actualizando

// Requerir el archivo de la clase Bee.php
require_once 'app/classes/Bee.php';

// Ejecutar el framework bee
Bee::fly();