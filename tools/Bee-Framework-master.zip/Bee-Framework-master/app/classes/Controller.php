<?php 

class Controller {
  public function probando() {
    echo 'Estamos probando el Controller...';
  }
}