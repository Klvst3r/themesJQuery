<?php 

class descargarController extends Controller {
  function __construct()
  {
  }
  
  function index() {
    echo 'En '.__CLASS__;
  }
}